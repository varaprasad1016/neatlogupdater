from flask import Flask, render_template, request, redirect, url_for, flash
import pandas as pd
from openpyxl import load_workbook

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Path to the Excel file
FILE_PATH = r"C:\Users\varap\Desktop\logupdater\Neatcom Customer Log.xlsx"

# Function to get sheet names dynamically
def get_sheet_names():
    wb = load_workbook(FILE_PATH, keep_vba=True)
    return wb.sheetnames

# Route: Index Page (Sheet Selection + Global Search)
@app.route("/", methods=["GET", "POST"])
def index():
    sheet_names = get_sheet_names()
    if request.method == "POST":
        if 'sheet_select' in request.form:
            selected_sheet = request.form.get("sheet_select")
            if selected_sheet:
                return redirect(url_for('manage', sheet_name=selected_sheet))
        elif 'global_search' in request.form:
            search_query = request.form.get("search_query")
            if search_query:
                return redirect(url_for('global_search', query=search_query))
    return render_template("index.html", sheet_names=sheet_names)

# Route: Manage Sheet
@app.route("/manage/<sheet_name>", methods=["GET", "POST"])
def manage(sheet_name):
    df = pd.read_excel(FILE_PATH, sheet_name=sheet_name, engine='openpyxl')
    df.fillna('', inplace=True)

    if request.method == "POST" and 'update_notes' in request.form:
        row_index = int(request.form['row_index'])
        notes = request.form['notes']
        df.at[row_index, 'Enter Notes'] = notes
        with pd.ExcelWriter(FILE_PATH, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
        flash("Notes updated successfully!", "success")
        return redirect(url_for('manage', sheet_name=sheet_name))

    headers = df.columns.tolist()
    data = df.values.tolist()
    return render_template("manage.html", headers=headers, data=data, selected_sheet=sheet_name)

# Route: Global Search Across All Sheets
@app.route("/global_search/<query>")
def global_search(query):
    results = []
    sheet_names = get_sheet_names()

    for sheet in sheet_names:
        df = pd.read_excel(FILE_PATH, sheet_name=sheet, engine='openpyxl')
        df.fillna('', inplace=True)

        filtered_data = df[df.apply(lambda row: row.astype(str).str.contains(query, case=False, na=False).any(), axis=1)]
        if not filtered_data.empty:
            results.append({"sheet_name": sheet, "headers": df.columns.tolist(), "data": filtered_data.values.tolist()})

    return render_template("global_search_results.html", query=query, results=results)

if __name__ == "__main__":
    app.run(debug=True)
